The codes were downloaded from

http://www.ssc.wisc.edu/~cfrederi/occ/OccCodes.html. 

This web page contains more information regarding these data.

1. OccCodeTable.csv - which is Table 1 transformed into a comma separated
dataset. This le contains 16 variables and each maps onto the respective column
number of the table. (Note: The First line of the File contains mnemonic variable
names).

2. OccCodes.do - a template to import these data into Stata

3. OccCodes.sas - a template to import these data into SAS

4. OccCodes.R - a template to import these data into R